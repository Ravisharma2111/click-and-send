export { default as PrimaryWebLayout } from "./primaryWeb";
export { default as SecondaryWebLayout } from "./secondaryWeb";
