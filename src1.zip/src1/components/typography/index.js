export { default as Heading } from './heading';
export { default as Title } from './title';
export { default as Paragraph } from './Paragraph';
export { default as TestimonialParagraph } from './testimonialParagraph';